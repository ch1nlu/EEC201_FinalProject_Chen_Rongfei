function d = disteu(x, y) 
% Input:x, y:   Two matrices whose each column is an a vector data.
% 
%Output:   d:      Element d(i,j) will be the Euclidean distance between two
%               column vectors X(:,i) and Y(:,j)
[C, R] = size(x);
[M2, P] = size(y); %size of input matrix
d = zeros(R, P);
if (C ~= M2)
    error('fail')
end
if (R < P)
    cp = zeros(1,P);%find euclidean distance
    for n = 1:R
        d(n,:) = sum((x(:, n+cp) - y) .^2, 1);
    end
else
    cp = zeros(1,R);
    for p = 1:P
        d(:,p) = sum((x - y(:, p+cp)) .^2, 1)';
    end
end

d = d.^0.5;
%dist = sum(min(d,[],2)) / size(d,1);